from flask import Flask, request, render_template
import pickle
model  =  pickle.load(open("F:/flaskapp/price.pkl", 'rb'))

app = Flask(__name__)
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_pred',methods=['POST'])
def y_pred():
    '''
    For rendering results on HTML GUI
    '''
    year     =request.form['year']
    month      =request.form['month']
    day        =request.form['day']
    data=[[ int(year),int(month),int(day)]]
    prediction  = model.predict(data)
    print(prediction)
    output=prediction[0][0]
    return render_template('index.html', prediction_text= 'Gas Price in Dollors {}'.format(output))
   

if __name__ == "__main__":
    app.run(debug=True)
